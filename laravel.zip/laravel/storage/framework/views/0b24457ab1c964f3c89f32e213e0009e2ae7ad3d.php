<!DOCTYPE html>
<html>
<body>

<h2>LOGIN</h2>

<form  method="post">
<?php echo csrf_field(); ?>
  <label for="fname">Email:</label><br>
  <input type="text" id="" name="email" value="" placeholde="username"><br>
  <label for="lname">password</label><br>
  <input type="password" id="" name="password" ><br><br>
  <input type="submit" value="login">
</form> 



</body>
</html>
<?php /**PATH C:\Users\Raju\Desktop\bus\resources\views/login.blade.php ENDPATH**/ ?>