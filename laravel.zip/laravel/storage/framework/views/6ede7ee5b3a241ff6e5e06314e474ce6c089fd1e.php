<!DOCTYPE html>
<html>
<body>

<h2>home</h2>

<table style="width:100%">
  <tr>
    <th>info</th>
    
  </tr>
  <tr>
    <td>Name: demo</td>
    
  </tr>
  <tr>
    <td>Email: demo@gmail.com</td>
    
  </tr>
  <tr>
    <td>Password:*****</td>
  </tr>
 
</table>

</body>
</html>
<?php /**PATH C:\Users\Raju\Desktop\bus\resources\views/home.blade.php ENDPATH**/ ?>